﻿
namespace Blogge.Core.StringConstants
{
   public static class ControllerNames
   {
       public const string Account = "Account";
       public const string Admin = "Admin";
       public const string Error = "Error";
       public const string Home = "Home";
       public const string Manage = "Manage";
       public const string Post = "Post";
    }
}
