﻿
using System.IO;


namespace Blogge.Interfaces.Facades.Systems
{
    public interface IMemoryStreamFacade
    {
        MemoryStream GetMemoryStream();
    }
}
